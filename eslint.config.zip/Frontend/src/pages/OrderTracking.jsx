import React, { useState } from 'react';
import axios from 'axios';

const orderStatuses = [
    'Order Placed',
    'Order Transit',
    'Out for Delivery',
    'Delivered'
];

const OrderTracking = () => {
    const [orderId, setOrderId] = useState('');
    const [orderDetails, setOrderDetails] = useState(null);
    const [error, setError] = useState('');

    const trackOrder = async () => {
        try {
            const { data } = await axios.get(`http://localhost:1000/api/orders/track/${orderId}`);
            setOrderDetails(data.order);
            setError('');
        } catch (err) {
            setError('Order not found');
            setOrderDetails(null);
        }
    };

    const handleNextStatus = async () => {
        if (!orderDetails) return;

        // Move to the next status
        const currentStatusIndex = orderStatuses.indexOf(orderDetails.status);
        if (currentStatusIndex < orderStatuses.length - 1) {
            const nextStatus = orderStatuses[currentStatusIndex + 1];
            try {
                const { data } = await axios.put(`http://localhost:1000/api/orders/update/${orderId}`, { status: nextStatus });
                setOrderDetails(data.order);
            } catch (error) {
                console.error("Error updating status:", error);
            }
        }
    };

    return (
        <div className="p-6">
            <h1 className="text-2xl font-bold mb-4">Track Your Order</h1>
            <input
                type="text"
                placeholder="Enter Order ID"
                value={orderId}
                onChange={(e) => setOrderId(e.target.value)}
                className="border p-2 rounded mr-2"
            />
            <button onClick={trackOrder} className="bg-blue-500 text-white p-2 rounded">
                Track Order
            </button>
            {error && <p className="text-red-500">{error}</p>}
            {orderDetails && (
                <div className="mt-6">
                    <h2 className="text-xl font-semibold">Order Status: {orderDetails.status}</h2>

                    {/* Stepper */}
                    <ol className="flex items-center w-full text-xs text-gray-900 font-medium sm:text-base mt-4">
                        {orderStatuses.map((status, index) => (
                            <li key={index} className={`flex w-full relative ${index < orderStatuses.length - 1 ? 'after:content-[""] after:w-full after:h-0.5 after:bg-gray-200 after:inline-block after:absolute lg:after:top-5 after:top-3 after:left-4' : ''}`}>
                                <div className="block whitespace-nowrap z-10">
                                    <span
                                        className={`w-6 h-6 ${index <= orderStatuses.indexOf(orderDetails.status)
                                            ? 'bg-indigo-600 border-2 border-transparent text-white'
                                            : 'bg-gray-50 border-2 border-gray-200 text-gray-900'
                                            } rounded-full flex justify-center items-center mx-auto mb-3 text-sm lg:w-10 lg:h-10`}
                                    >
                                        {index + 1}
                                    </span>
                                    <span className={`block text-sm ${index <= orderStatuses.indexOf(orderDetails.status) ? 'text-indigo-600' : 'text-gray-500'}`}>
                                        {status}
                                    </span>
                                </div>
                            </li>
                        ))}
                    </ol>

                    {/* Show Next Status button only if order isn't delivered */}
                    {orderDetails.status !== 'Delivered' && (
                        <button onClick={handleNextStatus} className="mt-4 bg-green-500 text-white p-2 rounded">
                            Next Status
                        </button>
                    )}
                </div>
            )}
        </div>
    );
};

export default OrderTracking;
