import { Box, Button, Heading, Text, VStack } from '@chakra-ui/react'
import React from 'react'
import { useSearchParams, useNavigate } from "react-router-dom"

const PaymentSuccess = () => {

    const searchQuery = useSearchParams()[0]
    const referenceNum = searchQuery.get("reference")

    const orderId = searchQuery.get("orderId");
    const navigate = useNavigate();
    console.log("PaymentSucess: ", orderId)

    const handleTrackOrder = () => {
        navigate(`/track-order?orderId=${orderId}`)
    }
    return (
        <Box>
            <VStack h="100vh" justifyContent={"center"}>
                <Heading textTransform={"uppercase"}>Order Successfull
                </Heading>
                <Text>
                    Reference Number: {referenceNum}
                </Text>
                {orderId && (
                    <Button onClick={handleTrackOrder} colorScheme='teal' mt={4}> Track Your Order</Button>
                )}
            </VStack>
        </Box>
    )
}

export default PaymentSuccess