import { Box, Center, Stack } from '@chakra-ui/react'
import React from 'react'
import axios from 'axios';
import Card from '../common-components/Card'

const ItemStore = () => {

    const checkoutHandler = async (amount, itemName) => {

        const { data: { key } } = await axios.get("http://localhost:1000/api/getkey")

        const { data: { order } } = await axios.post("http://localhost:1000/api/checkout", { amount, itemName })
        console.log()


        const options = {
            key,
            amount: order.amount,
            currency: "INR",
            name: "Himanshu Shivgotra",
            description: "Learning Payment Gateway",
            image: "https://media.licdn.com/media/AAYQAQSOAAgAAQAAAAAAAB-zrMZEDXI2T62PSuT6kpB6qg.png",
            order_id: order.id,
            callback_url: "http://localhost:1000/api/paymentverification",
            prefill: {
                name: "Himanshu shivgotra ",
                email: "himanshushivgotra@example.com",
                contact: "9000090000"
            },
            notes: {
                "address": "Razorpay Corporate Office"
            },
            theme: {
                "color": "#3399cc"
            },
            method: {
                upi: true,
            }
        };
        const razor = new window.Razorpay(options);
        razor.open();
    }

    return (

        <Box>
            {/* if phone then it will be in column otherwise row  */}
            <Stack h={"100vh"} justifyContent="center" direction={["column", "row"]}>
                <Card amount={5000} img={"https://www.reliancedigital.in/medias/Eureka-Forbes-Wet-and-Dry-Zeal-Vacuum-Cleaner-492391697-i-1-1200Wx1200H?context=bWFzdGVyfGltYWdlc3w2MjY3NHxpbWFnZS9qcGVnfGltYWdlcy9oZjgvaDJkLzk2MjU1MzYwNjk2NjIuanBnfGQ1ZTIzMTY4MjhkM2QyNjAyOWU3ZmJjOWFjYjAwNTA1NmQyNzc4YTcyZThkZTM5YzU1MTg0ZTc3MDU5NzIwZWI"} checkoutHandler={checkoutHandler} />
                <Card amount={3000} itemName={"EarBuds"} img={"https://www.reliancedigital.in/medias/boAt-Nirvana-TWS-Earbuds-493711847-i-1-1200Wx1200H-300Wx300H?context=bWFzdGVyfGltYWdlc3wzNDgyNHxpbWFnZS9qcGVnfGltYWdlcy9oNjIvaDJmLzEwMTg2ODQ4MjA2ODc4LmpwZ3xmYzZlOTgzNGY1ZmY5MDFiNGYyMWE0ZmRlOTM0YmUxZmEwMGVlMWM0ZTIwZTBjMjA2MDNlMDc0N2E4NDExZDBl"} checkoutHandler={checkoutHandler} />
                <Card amount={399} img={"https://www.reliancedigital.in/medias/Hp-Usb-Flash-Drive-Black-493838902-i-1-1200Wx1200H-300Wx300H?context=bWFzdGVyfGltYWdlc3wxNzkyMnxpbWFnZS9qcGVnfGltYWdlcy9oY2YvaGQwLzEwMDM1NDI2ODIwMTI2LmpwZ3w1M2Y1MzA5Y2VmZDdhNjhlMjM1YTFhNmQ0YmQ2ZDgyYzYyZmU3NGY3MGQxMGU1MTY5M2QyNmNkYjQ3ZWIyMDkwl"} checkoutHandler={checkoutHandler} />
            </Stack>
        </Box>

    )
}

export default ItemStore